#include<string>
#include<map>

using namespace std;

inline string reverseOp(string op)
{
	if (op == "==") return "!=";
	else if (op == "!=") return "==";
	else if (op == "<=") return ">";
	else if (op == ">=") return "<";
	else if (op == "<") return ">=";
	else if (op == ">") return "<=";
	else return op;
}
inline bool isCmpOp(string op) { return op == "==" || op == "!=" || op == "<" || op == ">" || op == "<=" || op == ">="; }
inline bool isDigit(string value) { return (value[0] >= '0' && value[0] <= '9') || value[0] == '-'; }
inline bool isChar(string value) { return value[0] == '\''; }
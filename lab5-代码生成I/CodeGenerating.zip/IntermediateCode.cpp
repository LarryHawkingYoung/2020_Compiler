#include"IntermediateCode.h"
#include<string>
#include<fstream>

using namespace std;

ofstream iout("intermediateCode.txt");

IntermediateCode::IntermediateCode()
{
}

IntermediateCode::~IntermediateCode()
{
	iout.close();
}

void IntermediateCode::insertQuat(string ans, string x, string op, string y)
{
	quatVec.push_back(Quaternion{ ans, x, op, y });
}

void IntermediateCode::outputQuats()
{
	for (int i = 0; i < quatVec.size(); i++)
	{
		// �����
		if (quatVec[i].op == "read")
		{
			iout << "read " << quatVec[i].ans << endl;
		}
		// д���
		else if (quatVec[i].op == "print")
		{
			if (quatVec[i].y == "") iout << "print " << quatVec[i].x << endl;
			else if (quatVec[i].x == "") iout << "print " << quatVec[i].y << endl;
			else iout << "print " << quatVec[i].x << " " << quatVec[i].y << endl;
		}
		// ��ֵ���
		else
		{
			if (quatVec[i].x == "") iout << quatVec[i].ans << " = " << quatVec[i].op << " " << quatVec[i].y << endl;
			else if (quatVec[i].op == "") iout << quatVec[i].ans << " = " << quatVec[i].x << endl;
			else iout << quatVec[i].ans << " = " << quatVec[i].x << " " << quatVec[i].op << " " << quatVec[i].y << endl;
		}
	}
}

